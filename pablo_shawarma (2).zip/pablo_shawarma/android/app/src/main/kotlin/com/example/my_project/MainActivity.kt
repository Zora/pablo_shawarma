package com.mycompany.pabloshawarma

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
