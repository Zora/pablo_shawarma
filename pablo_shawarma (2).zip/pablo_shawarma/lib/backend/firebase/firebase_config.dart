import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyD9_BYyoF1CA1ZCnfDJK0RTgD0nV7vJta0",
            authDomain: "pablo-shawarma-xrpucz.firebaseapp.com",
            projectId: "pablo-shawarma-xrpucz",
            storageBucket: "pablo-shawarma-xrpucz.appspot.com",
            messagingSenderId: "81019744708",
            appId: "1:81019744708:web:6d889cd606fe022aac7491"));
  } else {
    await Firebase.initializeApp();
  }
}
